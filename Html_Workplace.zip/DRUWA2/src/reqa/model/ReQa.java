package reqa.model;

public class ReQa {

}
