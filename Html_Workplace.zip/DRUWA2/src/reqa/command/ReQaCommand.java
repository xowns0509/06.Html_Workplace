package reqa.command;

public class ReQaCommand {

}
