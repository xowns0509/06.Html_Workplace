package reqa.command;

public class ReQaCommandException {

}
