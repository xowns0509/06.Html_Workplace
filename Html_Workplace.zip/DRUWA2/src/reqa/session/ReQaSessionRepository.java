package reqa.session;

public class ReQaSessionRepository {

}
