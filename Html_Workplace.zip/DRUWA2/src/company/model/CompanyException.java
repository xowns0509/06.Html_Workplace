package company.model;

public class CompanyException {

}
