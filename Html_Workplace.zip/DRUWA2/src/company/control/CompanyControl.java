package company.control;

public class CompanyControl {

}
