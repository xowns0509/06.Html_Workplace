package company.command;

public class CompanyCommandNull {

}
