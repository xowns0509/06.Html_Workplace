package company.command;

public class CompanyCommandException {

}
