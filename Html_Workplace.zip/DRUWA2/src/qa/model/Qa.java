package qa.model;

public class Qa {

}
