package qa.session;

public class QaSessionRepository {

}
