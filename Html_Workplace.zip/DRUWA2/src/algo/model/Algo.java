package algo.model;

public class Algo {

}
