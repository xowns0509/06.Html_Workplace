package algo.model;

public class AlgoException {

}
