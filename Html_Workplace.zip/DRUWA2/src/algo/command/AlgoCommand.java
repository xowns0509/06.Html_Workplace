package algo.command;

public interface AlgoCommand {

}
