package algo.command;

public class AlgoCommandNull {

}
