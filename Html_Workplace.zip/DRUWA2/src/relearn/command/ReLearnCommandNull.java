package relearn.command;

public class ReLearnCommandNull {

}
