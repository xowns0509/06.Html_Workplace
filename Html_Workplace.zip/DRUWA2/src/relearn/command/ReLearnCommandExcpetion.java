package relearn.command;

public class ReLearnCommandExcpetion {

}
