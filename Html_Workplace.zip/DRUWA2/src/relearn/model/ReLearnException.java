package relearn.model;

public class ReLearnException {

}
