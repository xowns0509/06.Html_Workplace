package learn.session;

public class LearnSessionRepository {

}
