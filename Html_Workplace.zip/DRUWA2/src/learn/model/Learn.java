package learn.model;

public class Learn {

}
