package learn.command;

public class LearnCommandException {

}
