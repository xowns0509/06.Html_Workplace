package member.control;

import javax.servlet.http.HttpServlet;

public class MemberControl extends HttpServlet{

}
