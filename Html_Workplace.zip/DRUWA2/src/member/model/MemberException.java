package member.model;

public class MemberException {

}
