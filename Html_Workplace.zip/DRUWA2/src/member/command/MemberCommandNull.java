package member.command;

public class MemberCommandNull implements MemberCommand{

}
