package member.command;

public class MemberCommandExcepton extends Exception{
	public MemberCommandExcepton(){
  		super();
  	}
  	
  public MemberCommandExcepton(String error){
  		super( error );
  	}
}
