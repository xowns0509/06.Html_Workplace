package hire.session;

public class HireSession {

}
