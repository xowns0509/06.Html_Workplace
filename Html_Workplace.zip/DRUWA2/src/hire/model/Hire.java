package hire.model;

public class Hire {

}
