package hire.command;

public interface HireCommand {

}
