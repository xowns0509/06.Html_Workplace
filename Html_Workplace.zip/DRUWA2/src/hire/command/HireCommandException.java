package hire.command;

public class HireCommandException {

}
