package qa.model;

public class QaException {

}
