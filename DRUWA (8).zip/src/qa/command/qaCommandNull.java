package qa.command;

import javax.servlet.http.HttpServletRequest;

public class qaCommandNull {


}
