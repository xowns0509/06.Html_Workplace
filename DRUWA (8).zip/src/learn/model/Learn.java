package learn.model;

public class Learn {
	
	//멤버 필드
	private int leNum;
	private String lePass;
	private String leTitle;
	private String leType;
	private String leTime;
	private String leContent;
	private String leCount;
	private String id;
	
	//기본생성자
	public Learn(){}

	public int getLeNum() {
		return leNum;
	}

	public void setLeNum(int leNum) {
		this.leNum = leNum;
	}

	public String getLePass() {
		return lePass;
	}

	public void setLePass(String lePass) {
		this.lePass = lePass;
	}

	public String getLeTitle() {
		return leTitle;
	}

	public void setLeTitle(String leTitle) {
		this.leTitle = leTitle;
	}

	public String getLeType() {
		return leType;
	}

	public void setLeType(String leType) {
		this.leType = leType;
	}

	public String getLeTime() {
		return leTime;
	}

	public void setLeTime(String leTime) {
		this.leTime = leTime;
	}

	public String getLeContent() {
		return leContent;
	}

	public void setLeContent(String leContent) {
		this.leContent = leContent;
	}

	public String getLeCount() {
		return leCount;
	}

	public void setLeCount(String leCount) {
		this.leCount = leCount;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
