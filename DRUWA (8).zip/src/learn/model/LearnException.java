package learn.model;

public class LearnException extends Exception{
	public LearnException(){
		super();
	}
	public LearnException(String error){
		super(error);
	}

}
