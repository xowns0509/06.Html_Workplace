package algo.model;

public class AlgoException extends Exception{
	public AlgoException(){
		super();
	}
	public AlgoException(String error){
		super(error);
	}
}
