package algo.model;

public class Algo {
	//멤버변수 선언
	private int algoMemNum;
	private int algoNum;
	private String id;
	private String algoAnswer;
	private String algoTime;
	public int getAlgoMemNum() {
		return algoMemNum;
	}
	public void setAlgoMemNum(int algoMemNum) {
		this.algoMemNum = algoMemNum;
	}
	public int getAlgoNum() {
		return algoNum;
	}
	public void setAlgoNum(int algoNum) {
		this.algoNum = algoNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlgoAnswer() {
		return algoAnswer;
	}
	public void setAlgoAnswer(String algoAnswer) {
		this.algoAnswer = algoAnswer;
	}
	public String getAlgoTime() {
		return algoTime;
	}
	public void setAlgoTime(String algoTime) {
		this.algoTime = algoTime;
	}
}
