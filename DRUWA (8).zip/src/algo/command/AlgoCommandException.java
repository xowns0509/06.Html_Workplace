package algo.command;

public class AlgoCommandException extends Exception{
	public AlgoCommandException(){
		super();
	}
	public AlgoCommandException(String error){
		super(error);
	}

}
