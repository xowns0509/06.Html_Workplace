package company.model;

public class Company {
	//멤버변수 등록
	private String companyId;
	private String companyPw;
	private String companyName;
	private String mgr;
	private String companyJob;
	private String companySales;
	private String companyType;
	private String setupDate;
	private String totalMan;
	private String totalSel;
	private String money;
	private String companyTel;
	private String fax;
	private String addr;
	private String companyResume;
	private String companyIntro;
	private String companyDetail;
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyID) {
		this.companyId = companyID;
	}
	public String getCompanyPw() {
		return companyPw;
	}
	public void setCompanyPw(String companyPw) {
		this.companyPw = companyPw;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getMgr() {
		return mgr;
	}
	public void setMgr(String mgr) {
		this.mgr = mgr;
	}
	public String getCompanyJob() {
		return companyJob;
	}
	public void setCompanyJob(String companyJob) {
		this.companyJob = companyJob;
	}
	public String getCompanySales() {
		return companySales;
	}
	public void setCompanySales(String companySales) {
		this.companySales = companySales;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getSetupDate() {
		return setupDate;
	}
	public void setSetupDate(String setupDate) {
		this.setupDate = setupDate;
	}
	public String getTotalMan() {
		return totalMan;
	}
	public void setTotalMan(String totalMan) {
		this.totalMan = totalMan;
	}
	public String getTotalSel() {
		return totalSel;
	}
	public void setTotalSel(String totalSel) {
		this.totalSel = totalSel;
	}
	public String getMoney() {
		return money;
	}
	public void setMoney(String money) {
		this.money = money;
	}
	public String getCompanyTel() {
		return companyTel;
	}
	public void setCompanyTel(String companyTel) {
		this.companyTel = companyTel;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getCompanyResume() {
		return companyResume;
	}
	public void setCompanyResume(String companyResume) {
		this.companyResume = companyResume;
	}
	public String getCompanyIntro() {
		return companyIntro;
	}
	public void setCompanyIntro(String companyIntro) {
		this.companyIntro = companyIntro;
	}
	public String getCompanyDetail() {
		return companyDetail;
	}
	public void setCompanyDetail(String companyDetail) {
		this.companyDetail = companyDetail;
	}
	
	

}
