package sh.model;

public class ShException {

}
