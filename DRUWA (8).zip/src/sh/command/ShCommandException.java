package sh.command;

public class ShCommandException {

}
