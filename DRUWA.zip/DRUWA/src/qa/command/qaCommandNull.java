package qa.command;

public class qaCommandNull {

}
