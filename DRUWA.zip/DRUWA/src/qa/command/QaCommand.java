package qa.command;

public class QaCommand {

}
