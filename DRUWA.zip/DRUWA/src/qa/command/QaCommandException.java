package qa.command;

public class QaCommandException {

}
