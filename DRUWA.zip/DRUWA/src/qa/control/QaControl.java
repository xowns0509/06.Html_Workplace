package qa.control;

public class QaControl {

}
