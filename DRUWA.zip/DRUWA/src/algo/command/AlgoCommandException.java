package algo.command;

public class AlgoCommandException {

}
