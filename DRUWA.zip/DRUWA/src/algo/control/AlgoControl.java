package algo.control;

public class AlgoControl {

}
