package relearn.command;

public class ReLearnCommand {

}
