package company.session;

public class CompanySessionRepository {

}
