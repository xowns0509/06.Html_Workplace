package company.model;

public class Company {

}
