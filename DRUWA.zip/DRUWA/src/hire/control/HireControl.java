package hire.control;

public class HireControl {

}
