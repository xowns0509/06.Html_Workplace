package hire.model;

public class HireException {

}
