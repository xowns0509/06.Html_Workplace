package hire.command;

public class HireCommandNull {

}
