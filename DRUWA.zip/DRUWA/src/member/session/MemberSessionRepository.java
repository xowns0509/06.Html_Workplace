package member.session;

public class MemberSessionRepository {

}
