package member.model;

//VO클래스
public class Member {

}
