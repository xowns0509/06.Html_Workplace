package learn.command;

public class LearnCommandNull {

}
