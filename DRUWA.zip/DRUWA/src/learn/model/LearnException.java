package learn.model;

public class LearnException {

}
