package reqa.command;

public class ReQaCommandNull {

}
