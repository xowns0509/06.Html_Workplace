package reqa.model;

public class ReQaException {

}
