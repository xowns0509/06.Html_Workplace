//jquery.js

$(function(){
	$('#info').tabs({
		active: 2,
		hide: true, //hide에다 true 주면 애니메이션 효과를 줌.
		heightStyle: 'auto'
	})
	
});