/**
 * 
 */

$(function() {
	
	// 누군가를 찾아 accordion 함수만 찾으면 끗.
		$('.accordion').accordion({
			animate: { duration:1000, easing: 'easeInElastic'}
		});
});